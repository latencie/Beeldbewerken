Ajit Jena
Lars Lokhoff

Assignment week 2