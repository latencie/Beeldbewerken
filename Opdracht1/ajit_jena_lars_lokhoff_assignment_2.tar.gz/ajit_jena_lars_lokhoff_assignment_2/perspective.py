
 # Subject: Beeld Bewerken

 # Student name .... Ajit Jena, Daan van Ingen
 # Student email ... <ajit.jena@gmail.com>, <lars.lokhoff@hotmail.com>.
 # Collegekaart .... 5730066, 10606165
 # Date ............ 10-02-2016
 # Comments ........ This file contains the function to perform a perpsective
 #                   Transformation
 # perspective.py


import numpy as np
import matplotlib.pyplot as plt
import cv2


# Main function that calls the functions to warp images and print them
def main():

    img_1 = cv2.imread('flyeronground.png', 0)
    img_2 = cv2.imread('perspective2.png', 0)
    perspective_image_1 = perspectiveTransform(
        img_1, 572, 187, 822, 172, 597, 587, 350, 555, 200, 300
        )
    perspective_image_2 = perspectiveTransform(
        img_2, 118, 35, 262, 35, 386, 230, 0, 230, 200, 300
        )

    show_images([img_1, perspective_image_1])
    show_images([img_2, perspective_image_2])


# This function is responsible for the perspective transformation and returns
# the output image that has been transformed
def perspectiveTransform(image, x1, y1, x2, y2, x3, y3, x4, y4, X, Y):

    #the 4 point correspondences matrix
    M = np.array([
        [x1, y1, 1, 0, 0, 0, 0*x1, 0*y1, 0],
        [0, 0, 0, x1, y1, 1, 0*x1, 0*y1, 0],
        [x2, y2, 1, 0, 0, 0, -X*x2, -X*y2, -X],
        [0, 0, 0, x2, y2, 1, 0*x2, 0*y2, 0],
        [x3, y3, 1, 0, 0, 0, -X*x3, -X*y3, -X],
        [0, 0, 0, x3, y3, 1, -Y*x3, -Y*y3, -Y],
        [x4, y4, 1, 0, 0, 0, 0*x4, 0*y4, 0],
        [0, 0, 0, x4, y4, 1, -Y*x4, -Y*y4, -Y]
        ])

    #create the SVD (U and D matrix not needed therefore _)
    _, _, V = np.linalg.svd(M)

    # use V to create p (last column)
    p = np.array([
        V[8][0], V[8][1], V[8][2], V[8][3], V[8][4], V[8][5], V[8][6],
        V[8][7], V[8][8]
        ])
    # Reshape vector p to obtain perspective transformation matrix
    A = p.reshape((3, 3))
    # Perspective warping
    warp_image = cv2.warpPerspective(image, A, (X, Y))
    return warp_image


# This function displays the given images together with their titles
def show_images(images, cm=plt.cm.gray, axis='off', titles=[]):
    number_images = len(images)
    fig = plt.figure()

    for i, img in enumerate(images):
        fig.add_subplot(1, number_images, i + 1)
        plt.axis(axis)

        if len(titles) != 0:
            plt.suptitle(titles[0])
            plt.title(titles[i+1])

        plt.imshow(img, cmap=cm)
    plt.show()


if __name__ == "__main__":
    main()
