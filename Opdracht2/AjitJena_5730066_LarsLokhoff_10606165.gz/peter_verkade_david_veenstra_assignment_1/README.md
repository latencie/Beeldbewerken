Lars Lokhoff
10606165

Ajit Jena
5730066

Opdracht 2

Voor exercise 2 graag de import van Axis3D uncommenten, pyflakes die vond dat wij deze import niet gebruikten terwijl we heb wel gebruiken in regel 29 bij projection = 3d. Sorry voor de last!