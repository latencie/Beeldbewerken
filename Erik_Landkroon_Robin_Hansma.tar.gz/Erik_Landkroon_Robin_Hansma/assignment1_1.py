import interpol as ip
import numpy as np
from pylab import lstsq, array, dot, inv, subplot, imshow, show
import cv2


def affineTransform(image, x1, y1, x2, y2, x3, y3, M, N):

    # De relatie matrix voor 3 point correspondences
    matrix = array([[x1, y1, 1, 0, 0, 0],
                   [0, 0, 0, x1, y1, 1],
                   [x2, y2, 1, 0, 0, 0],
                   [0, 0, 0, x2, y2, 1],
                   [x3, y3, 1, 0, 0, 0],
                   [0, 0, 0, x3, y3, 1]])

    # Maakt de vector q, dit zijn de punten waar de gekozen
    # punten naar toe worden gezet.
    q = array([[0], [0], [M], [0], [M], [N]])

    # Past least square methode toe op de matrix en q
    tmp = lstsq(matrix, q)

    # Maakt de matrix p, dit is de matrix die de oorspronkeleke punten
    # om zet naar de nieuwe punten
    p = array([[tmp[0][0][0], tmp[0][1][0], tmp[0][2][0]],
               [tmp[0][3][0], tmp[0][4][0], tmp[0][5][0]],
               [0, 0, 1]])

    # Maakt een nieuwe matrix van MxN
    b = np.zeros(shape=(N, M, 3))

    for i in range(0, M):
        for j in range(0, N):
            # Kijkt wat de coordinate van de pixel is in de oorspronkele foto
            v = dot(inv(p), ([[i], [j], [1]]))

            # Interpoleert over het punt
            b[j][i] = ip.interpolationLinear(image, v[1][0], v[0][0])

    return b


if __name__ == "__main__":
    # Leest de image uit een file en zet deze om naar RGB
    img = cv2.imread('images/cameraman.png')
    b, g, r = cv2.split(img)
    img = cv2.merge([r, g, b])
    img = img / 255.0

    # Plot de image
    subplot(1, 2, 1)
    imshow(img)

    img2 = affineTransform(img, 0, 100, 100, 0, 200, 100, 50, 50)

    # Plot de 2de image
    subplot(1, 2, 2)
    imshow(img2)
    show()
