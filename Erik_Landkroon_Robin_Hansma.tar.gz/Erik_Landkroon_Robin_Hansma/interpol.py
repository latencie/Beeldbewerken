# Student name .... Robin Hansma & Erik Landkroon
# Student email ... robin.hansma@student.uva.nl & erik.landkroon@student.uva.nl
# Collegekaart .... 10624368 & 10674918
# Date ............ 12-02-2015

import math


def interpolationLinear(img, x, y):
    i = math.floor(x)
    j = math.floor(y)
    a = x - i
    b = y - j

    # Berekent de RGB waarden van het punt x, y in de image
    r = (1 - a) * (1 - b) * img[i, j][0] \
        + (1 - a) * b * img[i, j + 1][0] \
        + a * (1 - b) * img[i + 1, j][0] \
        + a * b * img[i + 1, j + 1][0]
    g = (1 - a) * (1 - b) * img[i, j][1] \
        + (1 - a) * b * img[i, j + 1][1] \
        + a * (1 - b) * img[i + 1, j][1] \
        + a * b * img[i + 1, j + 1][1]
    b = (1 - a) * (1 - b) * img[i, j][2] \
        + (1 - a) * b * img[i, j + 1][2] \
        + a * (1 - b) * img[i + 1, j][2] \
        + a * b * img[i + 1, j + 1][2]

    return r, g, b
