import interpol as ip
import numpy as np
from pylab import subplot, array, svd, dot, inv, imshow, show
import cv2


def perspectiveTransform(image, x1, y1, x2, y2, x3, y3, x4, y4, M, N):

    # De relatie matrix voor 4 point correspondences
    matrix = array([[x1, y1, 1, 0, 0, 0, 0 * x1, 0 * y1, 0],
                    [0, 0, 0, x1, y1, 1, 0 * x1, 0 * y1, 0],
                    [x2, y2, 1, 0, 0, 0, -M * x2, -M * y2, -M],
                    [0, 0, 0, x2, y2, 1, 0 * x2, 0 * y2, 0],
                    [x3, y3, 1, 0, 0, 0, -M * x3, -M * y3, -M],
                    [0, 0,  0, x3, y3, 1, -N * x3, -N * y3, -N],
                    [x4, y4, 1, 0, 0, 0, 0 * x4, 0 * y4, 0],
                    [0, 0, 0, x4, y4, 1, -N * x4, -N * y4, -N]])

    U, D, V = svd(matrix)

    P = array([[V[8][0], V[8][1], V[8][2]],
               [V[8][3], V[8][4], V[8][5]],
               [V[8][6], V[8][7], V[8][8]]])

    # Maakt een nieuwe matrix van MxN
    b = np.zeros(shape=(N, M, 3))
    for i in range(0, M):
        for j in range(0, N):

            # Kijkt wat het coordinaat van de pixel is in de foto
            v = dot(inv(P), ([[i], [j], [1]]))
            v = v / v[2][0]

            # Interpoleert over het punt
            b[j][i] = ip.interpolationLinear(image, v[1][0], v[0][0])

    return b

if __name__ == "__main__":
    # Leest de image uit een file en zet deze om naar RGB
    img = cv2.imread('images/testfoto.png')
    b, g, r = cv2.split(img)
    img = cv2.merge([r, g, b])
    img = img / 255.0

    # Plot de image
    subplot(1, 2, 1)
    imshow(img)

    # Plot de 2de image
    img2 = perspectiveTransform(img, 20, 109, 123, 69,
                                277, 129, 176, 174, 220, 300)
    subplot(1, 2, 2)
    imshow(img2)
    show()
