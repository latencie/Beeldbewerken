# Student name .... Robin Hansma & Erik Landkroon
# Student email ... robin.hansma@student.uva.nl & erik.landkroon@student.uva.nl
# Collegekaart .... 10624368 & 10674918
# Date ............ 12-02-2015

from pylab import subplot, histogram, interp, \
    imread, imshow, bar, diff, plt, cumsum


def histogramEqualization(f, bins=100):
    hist, bin_edge = histogram(f, bins=bins)
    hist = hist.astype(float)/sum(hist)
    return interp(f, bin_edge[1:], cumsum(hist))

if __name__ == "__main__":
    img = imread('images/2015-02-16 22.45.54.jpg')

    # Plot de image
    subplot(2, 2, 1)
    imshow(img)

    # Plot de histogram van de image
    subplot(2, 2, 3)
    a, b = histogram(img, bins=30)
    bar(b[0:-1], a, width=diff(b)[0])

    # Plot de image na de equalization
    subplot(2, 2, 2)
    img2 = histogramEqualization(img)
    imshow(img2)

    # Plot de histogram van de image na de equalization
    subplot(2, 2, 4)
    a, b = histogram(img2, bins=30)
    bar(b[0:-1], a, width=diff(b)[0])

    plt.show()
