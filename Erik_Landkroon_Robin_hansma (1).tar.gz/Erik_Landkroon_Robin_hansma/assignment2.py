from pylab import mgrid, empty, pi, exp, sqrt, imread, imshow, subplot, cm
from scipy.ndimage import convolve1d, convolve
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.axes3d import Axes3D


# Create gaussian kernel
def Gauss(s):
    # Create empty kernel of size 3*s by 3*s and fill it
    kernel = empty([5*s, 5*s])
    for i in range(5*s):
        for j in range(5*s):
            y = i - (5.0*s)/2.0
            x = j - (5.0*s)/2.0
            kernel[j, i] = ((1.0 / (2.0 * pi * s**2))
                            * exp(-(x**2 + y**2)/(2.0 * s**2)))

    return kernel


# Create Gaussian kernel with seperated kernel
def Gauss1(s):
    # Create empty 1D kernel
    kernel = empty([5*s])
    for i in range(5*s):
        x = i - (5.0*s)/2.0
        kernel[i] = (1.0 / (s * sqrt(2.0 * pi))) * exp(-(x**2) / (2.0 * s**2))

    return kernel


# Plot the kernel of the gaussian convolution
def plotKernel(kernel):
    width, height = kernel.shape
    fig = plt.figure()
    ax = Axes3D(fig)

    X, Y = mgrid[0:width, 0:height]

    ax.plot_surface(X, Y, kernel)


# Calculate kernel gaussian derivative convolution
def gD(F, s, iorder, jorder):
    # Create empty kernel of size 5*s by 5*s and fill it
    kerneli = empty([5*s])
    kernelj = empty([5*s])
    for i in range(5*s):
            x = i - (5.0*s)/2.0

            # Looks what the iorder and picks the right function.
            if(iorder == 0):
                kerneli[i] = ((1.0 / (s * sqrt(2.0 * pi)))
                              * exp(-(x**2) / (2.0 * s**2)))
            elif(iorder == 1):
                kerneli[i] = ((-(x) / (s**3 * sqrt(2.0*pi)))
                              * exp(-(x**2 / (2.0 * s**2))))
            elif(iorder == 2):
                kerneli[i] = ((-(s**2 - x**2) / s**5 * sqrt(2.0 * pi))
                              * exp(-(x**2 / (2.0 * s**2))))

            # Looks what the jorder and picks the right function.
            if(jorder == 0):
                kernelj[i] = ((1.0 / (s * sqrt(2.0 * pi)))
                              * exp(-(x**2) / (2.0 * s**2)))
            elif(jorder == 1):
                kernelj[i] = ((-(x)/(s**3 * sqrt(2.0*pi)))
                              * exp(-(x**2 / (2.0 * s**2))))
            elif(jorder == 2):
                kernelj[i] = ((-(s**2 - x**2) / s**5 * sqrt(2.0 * pi))
                              * exp(-(x**2 / (2.0 * s**2))))

    H = convolve1d(F, kerneli, 0, mode='nearest')
    H = convolve1d(H, kernelj, 1, mode='nearest')
    return H


def crossings(F, s, fx, fy, fxx, fyy, fxy, x, y):
    # Looks for all the opposite sides in a 3x3 neighborhood.
    for k in range(0, 4):
        if k == 0:
            l = 1
            m = 1
        elif k == 1:
            l = 1
            m = 0
        elif k == 2:
            l = 0
            m = 1
        elif k == 3:
            l = -1
            m = 1

        # Calculate the value of the opposite sides.
        tmp1 = (fx[x + l, y + m] * fx[x + l, y + m] * fxx[x + l, y + m]
                + 2 * fx[x + l, y + m] * fy[x + l, y + m] * fxy[x + l, y + m]
                + fy[x + l, y + m] * fy[x + l, y + m] * fyy[x + l, y + m])
        tmp2 = (fx[x - l, y - m] * fx[x - l, y - m] * fxx[x - l, y - m]
                + 2 * fx[x - l, y - m] * fy[x - l, y - m] * fxy[x - l, y - m]
                + fy[x - l, y - m] * fy[x - l, y - m] * fyy[x - l, y - m])

        # Returns true if one is positive and one negative of a opposite side.
        if(tmp1 > 0 and tmp2 < 0 or tmp1 < 0 and tmp2 > 0):
            return True


def canny(F, s):
    # Calculate al the gaussian derivatives.
    fx = gD(F, s, 1, 0)
    fy = gD(F, s, 0, 1)
    fxx = gD(F, s, 2, 0)
    fyy = gD(F, s, 0, 2)
    fxy = gD(F, s, 1, 1)

    # Gets the height and width of the image.
    width, height = F.shape
    img = empty([width, height])

    t = 0.007
    for j in range(0, height - 1):
        for i in range(0, width - 1):
            # Compares the value of the first derivative with treshold t
            tmp = sqrt(fx[i, j]*fx[i, j] + fy[i, j] * fy[i, j])
            if tmp > t:
                # Checks if there is a crossing throug zero
                if(crossings(F, s, fx, fy, fxx, fyy, fxy, i, j)):
                    img[i, j] = tmp
    return img


if __name__ == "__main__":
    # Load image
    F = imread('images/cameraman.png')

    # # Plot original image
    subplot(3, 2, 1)
    imshow(F, cmap=cm.gray)

    # apply Gaussian convolution
    kernel = Gauss(19)
    G = convolve(F, kernel, mode='nearest')

    # Plot image after Gaussian convolution
    subplot(3, 2, 2)
    imshow(G, cmap=cm.gray)

    # Apply 1D Gaussian convolution
    seperatedKernel = Gauss1(7)
    H = convolve1d(F, seperatedKernel, 0, mode='nearest')
    H = convolve1d(H, seperatedKernel, 1, mode='nearest')

    # # Plot image after 1D Gaussian convolution
    subplot(3, 2, 3)
    imshow(H, cmap=cm.gray)

    # Plot image after Gaussian derivative
    I = gD(F, 2, 1, 1)
    subplot(3, 2, 4)
    imshow(I, cmap=cm.gray)

    # Plot the image after canny edge detection
    E = canny(F, 2)
    subplot(3, 2, 5)
    imshow(E, cmap=cm.gray)

    # Plot the kernel of the standard gaussian convolution
    plotKernel(kernel)

    plt.show()
