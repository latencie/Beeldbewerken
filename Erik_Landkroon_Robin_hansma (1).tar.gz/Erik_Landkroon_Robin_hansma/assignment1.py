from pylab import meshgrid, arange, pi, sin, cos, clf, quiver, show, imshow, cm


def f(x1, x2, y1, y2):
    x = arange(x1, x2)
    y = arange(y1, y2)
    Y, X = meshgrid(x, y)
    A = 1
    B = 2
    V = 6 * pi / 201
    W = 4 * pi / 201
    F = A * sin(V * X) + B * cos(W * Y)
    return F


def fx(x):
    A = 1
    V = 6 * pi / 201

    return A * V * cos(V * x)


def fy(y):
    B = 2
    W = 4 * pi / 201

    return -B * W * sin(W * y)


def qplot(F, Fx, Fy, x1, x2, x3, y1, y2, y3):
    xx = arange(x1, x2, x3)
    yy = arange(y1, y2, y3)
    YY, XX = meshgrid(yy, xx)

    FFx = Fx(XX)
    FFy = Fy(YY)

    clf()
    imshow(F, cmap=cm.gray, extent=(x1, x2, y1, y2))
    quiver(yy, xx, FFy, -FFx, color='red')


if __name__ == "__main__":
    F = f(-100, 101, -100, 101)
    qplot(F, fx, fy, -100, 101, 10, -100, 101, 10)
    show()
